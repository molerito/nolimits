export const siteConfig = {
  // Brand
  brand: {
    name: "No Limits",
    namePart1: "NO",
    namePart2: "LIMITS",
    logo: "/images/logo.png",
    logoAlt: "No Limits Logo",
  },

  // Navigation
  nav: {
    links: [
      { href: "#servicios", label: "Servicios" },
      { href: "#galeria", label: "Galeria" },
      { href: "#sobre-mi", label: "Sobre Mi" },
      { href: "#contacto", label: "Contacto" },
    ],
    ctaButton: "Clase Gratis",
  },

  // Hero Section
  hero: {
    badge: "Entrenamiento Personal",
    subtitle: "Supera tus limites y alcanza tu mejor version. Entrenamiento personalizado adaptado a tus objetivos.",
    ctaPrimary: "Reserva tu Clase Gratis",
    ctaSecondary: "Ver Servicios",
    scrollLabel: "Scroll hacia abajo",
    backgroundImage: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070",
  },

  // Services Section
  services: {
    badge: "Nuestros Servicios",
    title: "Todo lo que Necesitas para",
    titleHighlight: "Alcanzar tus Metas",
    description: "Ofrecemos una amplia gama de servicios de entrenamiento diseñados para ayudarte a superar tus limites.",
    items: [
      {
        icon: "Dumbbell",
        title: "Entrenamiento Personal",
        description: "Sesiones individuales adaptadas a tus objetivos y nivel de condicion fisica.",
      },
      {
        icon: "Users",
        title: "Clases Grupales",
        description: "Entrenamientos en grupo con ambiente motivador y seguimiento personalizado.",
      },
      {
        icon: "Target",
        title: "Crosstraining",
        description: "Entrenamiento funcional de alta intensidad para mejorar tu rendimiento global.",
      },
      {
        icon: "Flame",
        title: "Perdida de Peso",
        description: "Programas especificos para quemar grasa y alcanzar tu peso ideal.",
      },
      {
        icon: "Calendar",
        title: "Planificacion Deportiva",
        description: "Preparacion fisica para competiciones y eventos deportivos.",
      },
      {
        icon: "Trophy",
        title: "Transformacion Total",
        description: "Programa integral de cambio fisico y habitos de vida saludables.",
      },
    ],
  },

  // Gallery Section
  gallery: {
    badge: "Galeria",
    title: "Un Vistazo a Nuestros",
    titleHighlight: "Entrenamientos",
    description: "Conoce nuestras instalaciones y el ambiente de trabajo que te espera.",
    prevLabel: "Imagen anterior",
    nextLabel: "Siguiente imagen",
    images: [
      {
        src: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070",
        alt: "Entrenamiento con pesas",
      },
      {
        src: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070",
        alt: "Crossfit workout",
      },
      {
        src: "https://images.unsplash.com/photo-1581009146145-b5ef050c149a?q=80&w=2070",
        alt: "Entrenamiento funcional",
      },
      {
        src: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?q=80&w=2070",
        alt: "Clase grupal",
      },
      {
        src: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=2069",
        alt: "Personal training",
      },
    ],
  },

  // About Section
  about: {
    badge: "Sobre Mi",
    title: "Tu Entrenador,",
    titleHighlight: "Tu Guia",
    description1: "Soy un apasionado del fitness y el bienestar. Mi mision es ayudarte a descubrir tu potencial y superar los limites que creias tener. Con un enfoque personalizado y metodologias probadas, te acompaño en cada paso de tu transformacion.",
    description2: "Creo firmemente que todos somos capaces de lograr grandes cosas cuando tenemos la guia correcta y la motivacion adecuada. No se trata solo de entrenar, se trata de cambiar tu vida.",
    image: "https://images.unsplash.com/photo-1567013127542-490d757e51fc?q=80&w=1974",
    imageAlt: "Entrenador personal",
    statsNumber: "500+",
    statsLabel: "Clientes Transformados",
    highlights: [
      "Mas de 10 años de experiencia",
      "Certificaciones internacionales",
      "Entrenamiento 100% personalizado",
      "Seguimiento y apoyo continuo",
      "Resultados garantizados",
      "Horarios flexibles",
    ],
  },

  // Contact Section
  contact: {
    badge: "Contacto",
    title: "Reserva tu",
    titleHighlight: "Clase Gratis",
    description: "Da el primer paso hacia tu transformacion. Contactanos y empieza hoy.",
    infoTitle: "Informacion de Contacto",
    formTitle: "Envianos un Mensaje",
    submitButton: "Reservar Clase Gratis",
    successMessage: "Gracias por contactarnos. Te responderemos pronto.",
    info: [
      {
        icon: "MapPin",
        label: "Direccion",
        value: "Calle Principal 123, Ciudad",
      },
      {
        icon: "Phone",
        label: "Telefono",
        value: "+34 600 123 456",
      },
      {
        icon: "Mail",
        label: "Email",
        value: "info@nolimits.com",
      },
      {
        icon: "Clock",
        label: "Horario",
        value: "Lun - Vie: 7:00 - 21:00",
      },
    ],
    form: {
      name: {
        label: "Nombre Completo",
        placeholder: "Tu nombre",
      },
      email: {
        label: "Email",
        placeholder: "tu@email.com",
      },
      phone: {
        label: "Telefono",
        placeholder: "+34 600 000 000",
      },
      message: {
        label: "Mensaje",
        placeholder: "Cuentanos tus objetivos...",
      },
    },
  },

  // Footer
  footer: {
    copyright: "No Limits. Todos los derechos reservados.",
    socialLinks: [
      { icon: "Instagram", href: "#", label: "Instagram" },
      { icon: "Facebook", href: "#", label: "Facebook" },
      { icon: "Youtube", href: "#", label: "YouTube" },
    ],
    legalLinks: [
      { label: "Términos y Condiciones", href: "/terminos-y-condiciones" },
      { label: "Política de Privacidad", href: "/politica-de-privacidad" },
      { label: "Aviso Legal", href: "/aviso-legal" },
    ],
  },

  // WhatsApp
  whatsapp: {
    number: "34600123456",
    message: "Hola! Me gustaria obtener mas informacion sobre los entrenamientos.",
    ariaLabel: "Contactar por WhatsApp",
  },
}
